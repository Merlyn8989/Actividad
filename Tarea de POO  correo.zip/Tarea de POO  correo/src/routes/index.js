const { Router }= require('express');
const nodemailer = require('nodemailer');
const router = Router();

router.post('/send-email', (req, res)=>{
    const {destinatario, asunto, cuerpo} = req.body;
    contentHTML =`
        <h1>Información</h1>
        <ul>
            <li> Destinatario: ${destinatario} </li>
            <li> Asunto: ${asunto} </li>
        </ul>
        <p> Cuerpo: ${cuerpo} </p>
    `;

    class EnviarCorreo {

        constructor(transmitor, contraseña, destinatario, asunto, mensaje) {
            this.transmitor = transmitor;
            this.contraseña = contraseña;
            this.destinatario = destinatario;
            this.asunto = asunto;
            this.mensaje = mensaje;
        }
    
        configuracion() {
            const config = {
                host: 'smtp.gmail.com',
                puerto: 587,
                auth: {
                    user: this.transmitor,
                    pass: this.contraseña
                }
            }
    
            const transporte = nodemailer.createTransport(config);
            return transporte;
        }
    
        async envio() {
            const transporte = this.configuracion();
            console.log(transporte);
            const mensaje = {
                from: this.transmitor,
                to: this.destinatario,
                subject: this.asunto,
                text: this.mensaje
            }
            try {
                const info = await transporte.sendMail(mensaje);
                console.log('Message sent', info.messageId);
            } catch (error) {
                console.error(error);
            }
        }
    }
    
    const correo = new EnviarCorreo('merlynrajo@gmail.com','gpiy bxqp elta snhr', destinatario, asunto, cuerpo);
    correo.envio();

    if(correo){
        res.redirect('/success.html')
    }
});

module.exports = router;
